//-------------imports -----------------
const express = require('express');
const http = require('http')
const cors = require('cors')
const socketIO = require('socket.io')
const app = express();
const server = http.createServer(app);
const PORT = 5000;
const io = socketIO(server);
//--------------------------------------



//--------------middlewares-----------
const corsConfig = {
    credentials: true,
    origin: true,
};
app.use(cors(corsConfig));
//---------------------------------

var users = []
io.on("connection", async (socket) => {
    await socket.on("join_room", (args) => {
        users[socket.id] = args.user;
    })

    await socket.on("clicked", (cNum) => {
            //cNum will tell me counter number
        io.emit("clickit",cNum)  //on listening to clickit, it will click it
    })
})

// "clicked"  is when user is clicking any btn
// "clickit" is  - server asking client to click on it



server.listen(PORT, () => {
    console.log(`listening at ${PORT}`)
})
