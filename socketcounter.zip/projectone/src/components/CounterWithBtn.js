import React, {useState, useEffect} from 'react'
import socketIO from 'socket.io-client'
import './CounterWithBtn.css'

const CounterWithBtn = (props) => {

    const [counter, setCounter] = useState(0)

    const ENDPOINT = 'http://localhost:5000/'  //url of server

    var socket = socketIO(ENDPOINT, {
      cors: {
        origin: "ws://localhost:5000/socket.io/?EIO=4&transport=websocket",
        credentials: true
      }, transports : ['websocket']
    })

    const setCounterHandler = (e) => {
      e.preventDefault()  // to avoid page load
      setCounter(counter + 1)
      socket.emit("clicked", ` ${props.counterName}`);
    }

    useEffect(() => {
      if(props.socket === "true") {
          socket.on("connect", () => {
            socket.emit("join_room", 
              props.counterName
            );
          
        })

    
        return () => {
            socket.off();
        }
      }
      
  }, [socket])


  useEffect(() => {
    if(props.socket === "true") {
      socket.on("clickit", (args) => {
        if(args.trim() === props.counterName.trim())
        {
          setCounter(counter + 1)
        }
      })
     
         return () => {
             socket.off();
         }
    }
    
   }, [socket])


  return (

    <div className='card'> 
        {props.counterName} : {counter}
        <button onClick={setCounterHandler}>{props.counterName} Btn</button>
    </div>

  )
}

export default CounterWithBtn