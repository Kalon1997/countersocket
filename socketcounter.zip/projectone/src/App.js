import './App.css';
import CounterWithBtn from './components/CounterWithBtn';

function App() {


  return (
    <div className="App">
     <CounterWithBtn counterName = {'Counter1'} socket = {"true"}></CounterWithBtn>
     <CounterWithBtn counterName = {'Counter2'} socket = {"true"}></CounterWithBtn>
     <CounterWithBtn counterName = {'Counter3'} socket = {"true"}></CounterWithBtn>
     <CounterWithBtn counterName = {'Counter4'} socket = {"false"}></CounterWithBtn>
    </div>
  );
}

export default App;
